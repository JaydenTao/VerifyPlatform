# coding: utf-8

{
    'name': 'Custom Download File',
    'description': 'Widget for download custom files',
    'version': '1.0',
    'author': 'Erick Navarro',
    'website': 'http://erick.navarro.io',
    'depends': ['base', 'web'],
    'data': [
        'assets.xml'
    ]
}
